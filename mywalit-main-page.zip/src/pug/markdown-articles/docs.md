# Документация по фреймворку

### К проекту подключены:

**Утилиты,  стили**

* normalize.css
* bootstrap-4-grid/grid.min.css
* Иконки fontawesome v5.0.6

**Скрипты**

* jquery
* jquery-custom-scrollbar

**Шрифты**

* Open Sans
